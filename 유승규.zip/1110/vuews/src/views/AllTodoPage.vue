<template>
  <div>
    <h1>모든 할일</h1>
    <div class="box4">
      <input type="submit" value="+" class="plus"
      @click="createtodo"
      >
      <input type="text" v-model="newtodo" placeholder="할 일을 작성해주세요!"
      >
    </div>
    <hr>
    <div
    v-for="(todo,index) in todoList"
    :key="index"
    :todo="todo"
    class="box3 d-flex justify-content-between"
    >
    <div >
        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault"
        @click="todoCompleted(todo)"
        >
        <label class="form-check-label" for="flexCheckDefault">
            {{todo.content}}     
        </label>
    </div>
  <div>
      <i class="bi bi-star-fill" v-if="todo.isImportant === true" style="color:gold"
      @click="todoImportant(todo)"
      ></i>
      <i class="bi bi-star" v-if="todo.isImportant===false" style="color:gold"
      @click="todoImportant(todo)"
      ></i> 
  </div>
    </div>
  </div>
</template>

<script>


export default {
    name: 'AllTodoPage',
    data(){
      return{
        newtodo: null,
      }
    },
    computed:{
        todoList(){
            return this.$store.state.todo.list
        }
    },
    methods :{
      todoImportant(todo) {
        // console.log(todo.isImportant)
        this.$store.dispatch('todoImportant',todo)
      },
      todoCompleted(todo){
        // console.log(todo.isCompleted)
        this.$store.dispatch('todoCompleted',todo)
      },
      createtodo(){
        console.log(this.newtodo)
        if (this.newtodo) {
          this.$store.dispatch('createtodo',this.newtodo)
        }
      }
    }
    
}
</script>

<style>
.box3{
  border: solid black 2px;
  width: 70%;
  margin: 10px;
  border-radius: 10px;
  text-align: left;
  padding: 20px;
  padding-left: 30px;
  display: flex;
}

.form-check-label{
    margin-left: 10px;
}
.box4{
  margin: 10px;
  padding-left: 20px;
  display: flex;
}

.plus{
  background-color: white;
  margin-right: 10px;
  border-color: white;
}

</style>