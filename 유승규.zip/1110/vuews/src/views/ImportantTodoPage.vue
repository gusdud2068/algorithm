<template>
  <div>
    <h1>중요 할일</h1>
    <hr>
  </div>
</template>

<script>
export default {
    name: 'ImportantTodoPage',
}
</script>

<style>

</style>