<template>
  <div>
    <h1>오늘 할일</h1>
    <hr>
    <template>      
    <div
    v-for="(todo,index) in todoList"
    :key="index"
    :todo="todo"
    class="box3 d-flex justify-content-between"
    >
      <div>
          <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault"
          @click="todoCompleted(todo)"
          >
          <label class="form-check-label" for="flexCheckDefault">
              {{todo.content}}     
          </label>
      </div>
      <div>
          <i class="bi bi-star-fill" v-if="todo.isImportant === true" style="color:gold"
          @click="todoImportant(todo)"
          ></i>
          <i class="bi bi-star" v-if="todo.isImportant===false" style="color:gold"
          @click="todoImportant(todo)"
          ></i> 
      </div>
    </div>
    </template>
  </div>
</template>

<script>
export default {
    name: 'TodayTodoPage',
    computed:{
      todoList(){
            return this.$store.state.todo.list
        }
    },
    methods :{
      todoImportant(todo) {
        // console.log(todo.isImportant)
        this.$store.dispatch('todoImportant',todo)
      },
      todoCompleted(todo){
        // console.log(todo.isCompleted)
        this.$store.dispatch('todoCompleted',todo)
      },
    }
}
</script>

<style>

</style>