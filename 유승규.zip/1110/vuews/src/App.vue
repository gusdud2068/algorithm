<template>
  <div id="app">
    <div class="box1">
      <Sidebar/>   
    </div>
    <div class="box2">
      <router-view/>
      
    </div>
  </div>
</template>

<script>
import Sidebar from './components/SideBar.vue'

export default {
  name: 'App',
  components : {
    Sidebar,
  },
  
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  display: flex;
  
}

nav {
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}


div a.router-link-exact-active {
  color: #42b983;
}

.box1{
  border: solid black 2px;
  width: 30%;
  margin: 10px;
  border-radius: 10px;
  padding: 10px;
  height: 700px;
}
.box2{
  border: solid black 2px;
  width: 70%;
  margin: 10px;
  border-radius: 10px;
  text-align: left;
  padding: 10px;
  padding-left: 30px;
}
</style>
