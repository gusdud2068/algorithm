import Vue from 'vue'
import Vuex from 'vuex'
import todo from './modules/todo.js'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
  },
  getters: {
  },
  mutations: {
    TODO_IMPORTANT(state,todo){
      return todo.isImportant = !todo.isImportant
    },
    TODO_COMPLETED(state,todo){
      return todo.isCompleted = !todo.isCompleted
    },
    CREATETODO(state,todo){
      console.log(todo)
      return state.todo.list.push(todo)
    }
  },
  actions: {
    todoImportant(context,todo){
      context.commit('TODO_IMPORTANT',todo)
    },
    todoCompleted(context,todo){
      context.commit('TODO_COMPLETED',todo)
    },
    createtodo(context,newtodo){
      const ttime = new Date()
      const new_todo = {
        id : ttime,
        content : newtodo,
        isCompleted : false,
        isImportant : false,
        dueDateTime : `${ttime.getFullYear()}-${ttime.getMonth()+1}-${ttime.getDate()+1}T00:00`
      }
      context.commit('CREATETODO',new_todo)
    }
  },
  modules: {
    todo,
  }
})
