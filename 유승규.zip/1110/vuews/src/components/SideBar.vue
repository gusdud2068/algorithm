<template>
    <div class="side">
      <h1 class="text">
        <router-link to="/" style="text-decoration:none; " >모든</router-link>
        <br>
        <br>
        <router-link to="/today" style="text-decoration:none; " >오늘</router-link>
        <br>
        <br>
        <router-link to="/important" style="text-decoration:none; " >중요</router-link>
      </h1>
    </div>  
</template>

<script>
export default {
    name: 'SideBar',
}
</script>

<style>


</style>